export class userData{
    constructor(
        public date:Date,
        public pincode:number,
        public age:number
    ){

    }
}