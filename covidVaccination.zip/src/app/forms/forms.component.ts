import { Component, OnInit } from '@angular/core';
import { FormControl,FormGroup, FormGroupName } from "@angular/forms";
import { RegisterService } from "../register.service";
@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.scss']
})
export class FormsComponent implements OnInit {

  constructor(private register:RegisterService) { }
result1:any=[];
  ngOnInit(): void {
  }

  formObj=new FormGroup({
    pincode:new FormControl(''),
    date:new FormControl(''),
   
    age:new FormControl('')
  })

  onSubmit(){
    console.log(this.formObj.value)
    console.log(this.formObj.value.pincode)
    console.log(this.formObj.value.date)
    this.register.getByPincode(this.formObj.value.pincode,this.formObj.value.date).subscribe(data=>
      {
        // console.log(data)
      this.result1=data.sessions;
      console.log(this.result1);
      })
  }
}
